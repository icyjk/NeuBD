package NeuBD.ProyectoSII;

import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;


@Entity
public class Grupos_por_asignatura {

	@EmbeddedId
	private NewId_GrupoPorAsignatura_grupo_asignatura id;
	private String oferta;
	@ManyToMany
	@JoinTable(name = "jnd_GrupoPorAsignatura_Encuesta" , joinColumns = @JoinColumn(name = "gruposPorAsignatura_fk"), inverseJoinColumns = @JoinColumn(name = "encuesta_fk"))
	private List<Encuesta> encuestas;
	
	
	public List<Encuesta> getEncuestas() {
		return encuestas;
	}
	public void setEncuestas(List<Encuesta> encuestas) {
		this.encuestas = encuestas;
	}
	public NewId_GrupoPorAsignatura_grupo_asignatura getId() {
		return id;
	}
	public void setId(NewId_GrupoPorAsignatura_grupo_asignatura id) {
		this.id = id;
	}
	public String getOferta() {
		return oferta;
	}
	public void setOferta(String oferta) {
		this.oferta = oferta;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Grupos_por_asignatura other = (Grupos_por_asignatura) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Grupos_por_asignatura [id=" + id + ", oferta=" + oferta + ", encuestas=" + encuestas + "]";
	}
	
	
	
}

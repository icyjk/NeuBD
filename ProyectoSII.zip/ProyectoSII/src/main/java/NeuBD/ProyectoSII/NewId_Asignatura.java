package NeuBD.ProyectoSII;

import javax.persistence.Embeddable;

@Embeddable
public class NewId_Asignatura {
	private int referencia;
	@ManyToOne
	private Titulacion titulacion;
	public int getReferencia() {
		return referencia;
	}
	public void setReferencia(int referencia) {
		this.referencia = referencia;
	}
	public Titulacion getTitulacion() {
		return titulacion;
	}
	public void setTitulacion(Titulacion titulacion) {
		this.titulacion = titulacion;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + referencia;
		result = prime * result + ((titulacion == null) ? 0 : titulacion.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NewId_Asignatura other = (NewId_Asignatura) obj;
		if (referencia != other.referencia)
			return false;
		if (titulacion == null) {
			if (other.titulacion != null)
				return false;
		} else if (!titulacion.equals(other.titulacion))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "NewId_Asignatura [referencia=" + referencia + ", titulacion=" + titulacion + "]";
	}
	
}

package NeuBD.ProyectoSII;
import javax.persistence.Embeddable;

@Embeddable
public class NewId_Matricula_expediente {
	@ManyToOne
	private Expedientes expedientes;
	private String curso_academico;
	public Expedientes getExpedientes() {
		return expedientes;
	}
	public void setExpedientes(Expedientes expedientes) {
		this.expedientes = expedientes;
	}
	public String getCurso_academico() {
		return curso_academico;
	}
	public void setCurso_academico(String curso_academico) {
		this.curso_academico = curso_academico;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((curso_academico == null) ? 0 : curso_academico.hashCode());
		result = prime * result + ((expedientes == null) ? 0 : expedientes.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NewId_Matricula_expediente other = (NewId_Matricula_expediente) obj;
		if (curso_academico == null) {
			if (other.curso_academico != null)
				return false;
		} else if (!curso_academico.equals(other.curso_academico))
			return false;
		if (expedientes == null) {
			if (other.expedientes != null)
				return false;
		} else if (!expedientes.equals(other.expedientes))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "NewId_Matricula_expediente [expedientes=" + expedientes + ", curso_academico=" + curso_academico + "]";
	}
	
}

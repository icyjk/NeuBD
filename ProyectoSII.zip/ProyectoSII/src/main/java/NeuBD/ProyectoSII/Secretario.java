package NeuBD.ProyectoSII;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Inheritance(strategy = InheirtaceType.TABLE_PER_CLASS)
public class Secretario extends Usuario {
	
}

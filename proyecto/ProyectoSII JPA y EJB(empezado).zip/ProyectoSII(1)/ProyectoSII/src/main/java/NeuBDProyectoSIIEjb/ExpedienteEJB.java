package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Stateless
public class ExpedienteEJB {
	
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	

	public void eliminarExpediente(long num_expediente) throws NeuBDExceptions{
		
		Expedientes expedienteEntity = em.find(Expedientes.class,num_expediente);
		
		if (expedienteEntity == null) {
			throw new NeuBDExceptions();
		}
		
		em.remove(expedienteEntity);
		
	}
	
	public Expedientes visualizarExpediente(long num_expediente) throws NeuBDExceptions{

		Expedientes expedienteEntity = em.find(Expedientes.class,num_expediente);
		
		if (expedienteEntity == null) {
			throw new NeuBDExceptions();
		}
		
		return expedienteEntity;
	}
	
	public void modificarExpediente(long num_expediente, long nuevonum_expediente, boolean activo,double nota_media_provisional,int creditos_superado,
			int credito_fb,int credito_ob,int credito_op,int credito_cf,int credito_pe,int credito_tf) throws NeuBDExceptions{
		
		Expedientes expedienteEntity = em.find(Expedientes.class,num_expediente);
		
		if (expedienteEntity == null) {
			throw new NeuBDExceptions();
		}
		
		expedienteEntity.setNum_expediente(nuevonum_expediente);
		expedienteEntity.setActivo(activo);
		expedienteEntity.setNota_media_provisional(nota_media_provisional);
		expedienteEntity.setCreditos_superado(creditos_superado);
		expedienteEntity.setCredito_fb(credito_fb);
		expedienteEntity.setCredito_ob(credito_ob);
		expedienteEntity.setCredito_op(credito_op);
		expedienteEntity.setCredito_cf(credito_cf);
		expedienteEntity.setCredito_pe(credito_pe);
		expedienteEntity.setCredito_tf(credito_tf);
	}

}

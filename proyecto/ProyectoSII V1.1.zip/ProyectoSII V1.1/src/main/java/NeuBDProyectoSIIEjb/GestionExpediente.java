package NeuBDProyectoSIIEjb;

import javax.ejb.Local;

import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Local
public interface GestionExpediente {
	
	public void eliminarExpediente(long num_expediente) throws NeuBDExceptions;
	
	public Expedientes visualizarExpediente(long num_expediente) throws NeuBDExceptions;
	
	public void modificarExpediente(long num_expediente, long nuevonum_expediente, boolean activo,double nota_media_provisional,int creditos_superado,
			int credito_fb,int credito_ob,int credito_op,int credito_cf,int credito_pe,int credito_tf) throws NeuBDExceptions;
		
	
	
	

}

package NeuBDProyectoSIIEjb;

import javax.ejb.Local;

import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;


@Local
public interface GestionGrupo {
	
	public void eliminarGrupo(String id) throws NeuBDExceptions;
	
	public Grupo visualizarGrupo(String id) throws NeuBDExceptions;
	
	public void modificarGrupo(String id,String nuevoid,String curso,char letra,String turno_mañana_tarde,boolean ingles,String visible,
			String asignar,int plazas) throws NeuBDExceptions;
}

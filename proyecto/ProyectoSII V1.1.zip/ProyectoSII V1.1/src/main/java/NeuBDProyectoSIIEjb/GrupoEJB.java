package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Stateless
public class GrupoEJB {
	
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	public void eliminarGrupo(String id) throws NeuBDExceptions{
		
		Grupo grupoEntity = em.find(Grupo.class, id);
		
		if (grupoEntity == null) {
			throw new NeuBDExceptions();
		}
		
		em.remove(grupoEntity);
		
	}
	
	public Grupo visualizarGrupo(String id) throws NeuBDExceptions{

		Grupo grupoEntity = em.find(Grupo.class, id);
		
		if (grupoEntity == null) {
			throw new NeuBDExceptions();
		}
		
		return grupoEntity;
	}
	
	public void modificarGrupo(String id,String nuevoid,String curso,char letra,String turno_mañana_tarde,boolean ingles,String visible,
			String asignar,int plazas) throws NeuBDExceptions{
		
		Grupo grupoEntity = em.find(Grupo.class, id);
		
		if (grupoEntity == null) {
			throw new NeuBDExceptions();
		}
		
		grupoEntity.setId(nuevoid);
		grupoEntity.setCurso(curso);
		grupoEntity.setLetra(letra);
		grupoEntity.setTurno_mañana_tarde(turno_mañana_tarde);
		grupoEntity.setIngles(ingles);
		grupoEntity.setVisible(visible);
		grupoEntity.setAsignar(asignar);
		grupoEntity.setPlazas(plazas);
		
		
	}
}



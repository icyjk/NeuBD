package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Titulacion;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Stateless
public class TitulacionEJB {
	
	
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	
	public void eliminarTitulacion(int titulacion) throws NeuBDExceptions{
		
		Titulacion titulacionEntity = em.find(Titulacion.class, titulacion);
		
		if (titulacionEntity == null) {
			throw new NeuBDExceptions();
		}
		
		em.remove(titulacionEntity);
		
	}
	
	
	
	public Titulacion visualizartitulacion(int titulacion) throws NeuBDExceptions{
		
		Titulacion titulacionEntity = em.find(Titulacion.class, titulacion);
		
		if (titulacionEntity == null) {
			throw new NeuBDExceptions();
		}
		
		return titulacionEntity;
		
	}
	
	public void modificarTitulacion(int codigo, int nuevocodigo, String nombre,int creditos) throws NeuBDExceptions{
		
		Titulacion titulacionEntity = em.find(Titulacion.class, codigo);
		
		if (titulacionEntity == null) {
			throw new NeuBDExceptions();
		}
		
		titulacionEntity.setCodigo(nuevocodigo);
		titulacionEntity.setNombre(nombre);
		titulacionEntity.setCreditos(creditos);
	}
	
	
	

}

package NeuBDProyectoSIIEjb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Asignatura;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSIIexceptions.AsignaturaNoEncontradaException;
import NeuBDProyectoSIIexceptions.ExpedienteNoEncontradoException;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;
import NeuBDProyectoSIIexceptions.usuarioNoEncontradoException;

@Stateless
public class ExpedienteEJB implements GestionExpediente{
	
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	@Override
	public void eliminarExpediente(long num_expediente) throws ExpedienteNoEncontradoException{
		
		Expedientes expedienteEntity = em.find(Expedientes.class,num_expediente);
		
		if (expedienteEntity == null) {
			throw new ExpedienteNoEncontradoException();
		}
		
		em.remove(expedienteEntity);
		
	}
	
	@Override
	public Expedientes visualizarExpediente(long num_expediente) throws ExpedienteNoEncontradoException{

		Expedientes expedienteEntity = em.find(Expedientes.class,num_expediente);
		
		if (expedienteEntity == null) {
			throw new ExpedienteNoEncontradoException();
		}
		
		return expedienteEntity;
	}
	
	@Override
	public void modificarExpediente(Expedientes expediente) throws NeuBDExceptions{
		
		Expedientes exp = em.find(Expedientes.class, expediente.getNum_expediente());
		
		if (exp == null) {
			throw new ExpedienteNoEncontradoException();
		}
		
		em.merge(exp);
	}
	
	
	@Override
	public List<Expedientes> listaExpedientes() throws NeuBDExceptions {
		return em.createNamedQuery("Expedientes.todos", Expedientes.class).getResultList();
	}
	


}

package NeuBDProyectoSIIEjb;

import java.util.List;

import javax.ejb.Local;

import NeuBDProyectoSII.Asignatura;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Local
public interface GestionExpediente {
	
	public void eliminarExpediente(long num_expediente) throws NeuBDExceptions;
	
	public Expedientes visualizarExpediente(long num_expediente) throws NeuBDExceptions;
	
	public void modificarExpediente(Expedientes expediente) throws NeuBDExceptions;
		
	public List<Expedientes> listaExpedientes() throws NeuBDExceptions;
	
	
	

}

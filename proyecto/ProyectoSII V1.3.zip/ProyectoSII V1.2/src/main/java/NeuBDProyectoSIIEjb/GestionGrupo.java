package NeuBDProyectoSIIEjb;

import javax.ejb.Local;

import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;


@Local
public interface GestionGrupo {
	
	public void eliminarGrupo(String id) throws NeuBDExceptions;
	
	public Grupo visualizarGrupo(String id) throws NeuBDExceptions;
	
	public void modificarGrupo(Grupo grupo) throws NeuBDExceptions;
	
}
			

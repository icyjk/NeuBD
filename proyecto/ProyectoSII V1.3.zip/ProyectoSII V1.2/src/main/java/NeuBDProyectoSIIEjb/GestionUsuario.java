package NeuBDProyectoSIIEjb;
import javax.ejb.Local;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSII.Usuario;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;
import NeuBDProyectoSIIexceptions.usuarioNoEncontradoException;



@Local
public interface GestionUsuario {

	public boolean iniciarSesion(String ID, String password) throws NeuBDExceptions;
	
//	public void cerrarSesion();
	
	
	public void eliminarUsuario(String id) throws NeuBDExceptions;
	
	public Usuario visualizarUsuario(String id) throws NeuBDExceptions;
	
	public void modificarUsuario(Usuario usuario) throws NeuBDExceptions;
	
}

package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Stateless
public class GrupoEJB implements GestionGrupo {
	
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	@Override
	public void eliminarGrupo(String id) throws NeuBDExceptions{
		
		Grupo grupoEntity = em.find(Grupo.class, id);
		
		if (grupoEntity == null) {
			throw new NeuBDExceptions();
		}
		
		em.remove(grupoEntity);
		
	}
	
	@Override
	public Grupo visualizarGrupo(String id) throws NeuBDExceptions{

		Grupo grupoEntity = em.find(Grupo.class, id);
		
		if (grupoEntity == null) {
			throw new NeuBDExceptions();
		}
		
		return grupoEntity;
	}
	
	@Override
	public void modificarGrupo(Grupo grupo) throws NeuBDExceptions { //EL grupo debe pasarse ya modificado
		Grupo grupoEntity = em.find(Grupo.class, grupo.getId());
		
		if (grupoEntity == null) {
			throw new NeuBDExceptions();
		}
		
		em.merge(grupo); //Manda a la base de datos el grupo modificado, y lo mezcla con el grupo que habia
		
	}
	
}



package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Titulacion;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Stateless
public class TitulacionEJB implements GestionTitulacion {
	
	
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	
	@Override
	public void eliminarTitulacion(int titulacion) throws NeuBDExceptions{
		
		Titulacion titulacionEntity = em.find(Titulacion.class, titulacion);
		
		if (titulacionEntity == null) {
			throw new NeuBDExceptions();
		}
		
		em.remove(titulacionEntity);
		
	}
	
	
	@Override
	public Titulacion visualizartitulacion(int titulacion) throws NeuBDExceptions{
		
		Titulacion titulacionEntity = em.find(Titulacion.class, titulacion);
		
		if (titulacionEntity == null) {
			throw new NeuBDExceptions();
		}
		
		return titulacionEntity;
		
	}
	
	@Override
	public void modificarTitulacion(int codigo, int nuevocodigo, String nombre,int creditos) throws NeuBDExceptions{
		
		Titulacion titulacionEntity = em.find(Titulacion.class, codigo);
		
		if (titulacionEntity == null) {
			throw new NeuBDExceptions();
		}
		
		titulacionEntity.setCodigo(nuevocodigo);
		titulacionEntity.setNombre(nombre);
		titulacionEntity.setCreditos(creditos);
	}
	
	
	

}

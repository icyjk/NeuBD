package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSII.Usuario;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;
import NeuBDProyectoSIIexceptions.usuarioNoEncontradoException;

@Stateless
public class UsuarioEJB implements GestionUsuario {
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	@Override
	public boolean iniciarSesion(String ID, String password) throws usuarioNoEncontradoException {
		Usuario usuario = em.find(Usuario.class, ID);
		boolean correcto=false;
		

		if(usuario==null) {
			throw new usuarioNoEncontradoException();
		}
		
		
		if(usuario.getPassword()!=password) {
			throw new usuarioNoEncontradoException();
		}
		
		correcto=true;
		
		return correcto;
	}

	@Override
	public void eliminarUsuario(String id) throws usuarioNoEncontradoException {
	
		Usuario usuario = em.find(Usuario.class, id);
		
		if (usuario == null) {
			throw new usuarioNoEncontradoException();
		}
		
		em.remove(usuario);
		
	}

	@Override
	public Usuario visualizarUsuario(String id) throws usuarioNoEncontradoException {
		Usuario usuario = em.find(Usuario.class, id);
		
		if (usuario == null) {
			throw new usuarioNoEncontradoException();
		}
		
		return usuario;
	}

	@Override
	public void modificarUsuario(Usuario usuario) throws usuarioNoEncontradoException {
		
		Usuario usuario1 = em.find(Usuario.class, usuario.getID());
		
		if (usuario1 == null) {
			throw new usuarioNoEncontradoException();
		}
		
		em.merge(usuario); //Manda a la base de datos el grupo modificado, y lo mezcla con el grupo que habia
	}
	
//	public void cerrarSesion(String ID, String password) {
//		
//	}
	
}

package NeuBDProyectoSIIexceptions;

public class AsignaturaNoEncontradaException extends NeuBDExceptions{

}

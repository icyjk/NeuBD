package NeuBDProyectoSIIEjb;

import javax.ejb.Local;

import NeuBDProyectoSII.Centro;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Local
public interface GestionCentro {
	public void insertarCentro(Centro centro) throws NeuBDExceptions;
	public void eliminarCentro(String id) throws NeuBDExceptions;
	public void modificarCentro(Centro centro) throws NeuBDExceptions;
}

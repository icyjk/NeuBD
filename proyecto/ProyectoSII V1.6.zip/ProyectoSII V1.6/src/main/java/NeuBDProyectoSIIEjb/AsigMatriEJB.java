package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Asignatura_matricula;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSIIexceptions.AsignaturaPorMatriculaNoEncontradaException;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;
import NeuBDProyectoSIIexceptions.usuarioNoEncontradoException;

@Stateless
public class AsigMatriEJB implements GestionAsigMatri{
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	

	@Override
	public void eliminarAsigMatri(String id) throws NeuBDExceptions {
		Asignatura_matricula AsigMatri = em.find(Asignatura_matricula.class, id);
		
		if (AsigMatri == null) {
			throw new AsignaturaPorMatriculaNoEncontradaException();
		}
		
		em.remove(AsigMatri);
		
		
	}

	@Override
	public Asignatura_matricula visualizarAsigMatri(String id) throws NeuBDExceptions {
		
		Asignatura_matricula AsigMatri = em.find(Asignatura_matricula.class, id);
		
		if (AsigMatri == null) {
			throw new AsignaturaPorMatriculaNoEncontradaException();
		}
		
		return AsigMatri;
	}

	@Override
	public void modificarAsigMatri(Grupo AsigMatri) throws NeuBDExceptions {
		Asignatura_matricula AsigMatri1 = em.find(Asignatura_matricula.class, AsigMatri);
		
		
		if (AsigMatri1 == null) {
			throw new usuarioNoEncontradoException();
		}
		
		em.merge(AsigMatri1); //Manda a la base de datos el grupo modificado, y lo mezcla con el grupo que habia
	}

}

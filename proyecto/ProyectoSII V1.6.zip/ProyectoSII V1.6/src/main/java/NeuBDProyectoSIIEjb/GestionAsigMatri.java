package NeuBDProyectoSIIEjb;

import NeuBDProyectoSII.Asignatura_matricula;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

public interface GestionAsigMatri {

	public void eliminarAsigMatri(String id) throws NeuBDExceptions;
	
	public Asignatura_matricula visualizarAsigMatri(String id) throws NeuBDExceptions;
	
	public void modificarAsigMatri(Grupo AsigMatri) throws NeuBDExceptions;
}

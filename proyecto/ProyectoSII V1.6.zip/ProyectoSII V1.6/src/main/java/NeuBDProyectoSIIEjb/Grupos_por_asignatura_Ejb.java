package NeuBDProyectoSIIEjb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Asignatura;
import NeuBDProyectoSII.Grupos_por_asignatura;
import NeuBDProyectoSIIexceptions.AsignaturaNoEncontradaException;
import NeuBDProyectoSIIexceptions.GruposPorAsignaturaNoEncontradoException;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Stateless
public class Grupos_por_asignatura_Ejb implements GestionGrupoPorAsignatura{
	@PersistenceContext(unitName = "ProyectoSII")
	private EntityManager em;

	@Override
	public List<Grupos_por_asignatura> listaGruposPorAsignatura() throws NeuBDExceptions {
		return em.createNamedQuery("GruposPorAsignatura.todos", Grupos_por_asignatura.class).getResultList();
	}

	@Override
	public Grupos_por_asignatura buscarGruposPorAsignatura(Asignatura asignatura)
			throws NeuBDExceptions, GruposPorAsignaturaNoEncontradoException, AsignaturaNoEncontradaException {
		Asignatura a = em.find(Asignatura.class, asignatura);
		if(a==null)
			throw new AsignaturaNoEncontradaException();
		Grupos_por_asignatura g = em.find(Grupos_por_asignatura.class, a.getReferencia());
		if(g == null)
			throw new GruposPorAsignaturaNoEncontradoException();
		
		return g;
	}
	
	
	//Provisional
	@Override
	public void modificarGruposPorAsignatura(Grupos_por_asignatura grupos) throws NeuBDExceptions, GruposPorAsignaturaNoEncontradoException {
		Grupos_por_asignatura g = em.find(Grupos_por_asignatura.class, grupos.getGrupo());//He puesto getGrup() por poner algo
		if(g == null) {
			throw new GruposPorAsignaturaNoEncontradoException();
		}
		em.merge(g);
		
	}
	//Provisional
	@Override
	public void eliminarGruposPorAsignatura(Grupos_por_asignatura grupo) throws NeuBDExceptions, GruposPorAsignaturaNoEncontradoException {
		buscarGruposPorAsignatura(grupo.getAsignatura());
		em.remove(em.merge(grupo));
	}

}

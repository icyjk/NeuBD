package NeuBDProyectoSIIEjb;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import NeuBDProyectoSII.Encuesta;
import NeuBDProyectoSIIexceptions.EncuestaNoEncontradaException;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;


@Stateless
public class EncuestaEJB implements GestionEncuesta{

	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	@Override
	public void eliminarEncuesta(Date fecha) throws EncuestaNoEncontradaException {
		// TODO Auto-generated method stub
		Encuesta encuesta = em.find(Encuesta.class, fecha);
		
		if (encuesta == null) {
			throw new EncuestaNoEncontradaException();
		}
		
		em.remove(encuesta);
	}

	@Override
	public Encuesta visualizarEncuesta(Date fecha) throws EncuestaNoEncontradaException {
		// TODO Auto-generated method stub
		Encuesta encuesta = em.find(Encuesta.class, fecha);
		
		if (encuesta == null) {
			throw new EncuestaNoEncontradaException();
		}
		
		return encuesta;
	}

	@Override
	public void modificarEncuesta(Encuesta encuesta) throws EncuestaNoEncontradaException {
		// TODO Auto-generated method stub
		Encuesta encuesta1 = em.find(Encuesta.class, encuesta.getFecha_de_envio());
		
		if (encuesta1 == null) {
			throw new EncuestaNoEncontradaException();
		}
		
		em.merge(encuesta1);
		
	}

	@Override
	public List<Encuesta> listaEncuestas() throws NeuBDExceptions {
		
		return em.createNamedQuery("Encuesta.todos",Encuesta.class).getResultList();
	}

}

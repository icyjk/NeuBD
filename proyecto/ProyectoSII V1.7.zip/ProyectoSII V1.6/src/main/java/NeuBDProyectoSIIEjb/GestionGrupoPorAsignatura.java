package NeuBDProyectoSIIEjb;

import java.util.List;

import javax.ejb.Local;

import NeuBDProyectoSII.Asignatura;
import NeuBDProyectoSII.Grupos_por_asignatura;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Local
public interface GestionGrupoPorAsignatura {
	public List<Grupos_por_asignatura> listaGruposPorAsignatura()throws NeuBDExceptions;
	public Grupos_por_asignatura buscarGruposPorAsignatura(Asignatura asigantura) throws NeuBDExceptions;
	public void modificarGruposPorAsignatura(Grupos_por_asignatura grupos) throws NeuBDExceptions;
	public void eliminarGruposPorAsignatura(Grupos_por_asignatura grupos) throws NeuBDExceptions;
}

package NeuBDProyectoSIIexceptions;

public class EncuestaNoEncontradaException extends NeuBDExceptions{

}

package NeuBDProyectoSIIexceptions;

public class GrupoNoEncontrado extends NeuBDExceptions{

}

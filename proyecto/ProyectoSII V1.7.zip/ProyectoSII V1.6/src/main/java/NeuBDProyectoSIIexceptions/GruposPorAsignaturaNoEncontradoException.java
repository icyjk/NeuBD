package NeuBDProyectoSIIexceptions;

public class GruposPorAsignaturaNoEncontradoException extends NeuBDExceptions {

}

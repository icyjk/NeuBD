package NeuBDProyectoSIIexceptions;

public class MatriculaNoEncontradaException extends NeuBDExceptions{

}

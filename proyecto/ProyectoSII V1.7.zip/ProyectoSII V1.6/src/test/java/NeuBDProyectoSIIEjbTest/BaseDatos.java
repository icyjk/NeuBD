package NeuBDProyectoSIIEjbTest;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Centro;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSII.Titulacion;

public class BaseDatos {
	
	public static void inicializaBaseDatos(String nombreUnidadPersistencia) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(nombreUnidadPersistencia);
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		//centro
		Centro centroETSI = new Centro("ETSI","Calle ruben del pozo","639004675",null);
		
		List<Centro> listacentros = new ArrayList<Centro>();
		listacentros.add(centroETSI);
		
		em.persist(centroETSI);
		//Titulacion
		Titulacion titulacionInf = new Titulacion("Informatica", 360,listacentros, null, null, null);
		
		em.persist(titulacionInf);
		
		//Grupo
		Grupo grupoAinf = new Grupo("1",'A',"Mañana",true, true, "", 50 , titulacionInf, null, null);
		
		em.persist(grupoAinf);
		
		//Alumno
		Expedientes expediente = new Expedientes();
		List<Expedientes> listaExpedientes = new ArrayList<Expedientes>();
		listaExpedientes.add(expediente);
		em.persist(expediente);
		Alumno alumno = new Alumno("788399","Gustavo","Gracias","Molina","ola@prueba.com","ola@uma.es","75848437","calle falsa n25","malaga","malaga","29010",listaExpedientes);
		
		em.persist(alumno);
		
		

		
		
		
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

}

package NeuBDProyectoSIIEjb;

import java.util.List;

import javax.ejb.Local;

import NeuBDProyectoSII.Optativa;
import NeuBDProyectoSII.Titulacion;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;


@Local
public interface GestionTitulacion {
	
public void eliminarTitulacion(int titulacion) throws NeuBDExceptions;

public Titulacion visualizartitulacion(int titulacion) throws NeuBDExceptions;
	
public void modificarTitulacion(int codigo, int nuevocodigo, String nombre,int Creditos) throws NeuBDExceptions;

public List<Titulacion> listaTitulacion()throws NeuBDExceptions;

}

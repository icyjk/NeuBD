package NeuBDProyectoSIIEjb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSIIexceptions.ExpedienteNoEncontradoException;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;
import NeuBDProyectoSIIexceptions.usuarioNoEncontradoException;

@Stateless
public class ExpedienteEJB {
	
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	

	public void eliminarExpediente(long num_expediente) throws ExpedienteNoEncontradoException{
		
		Expedientes expedienteEntity = em.find(Expedientes.class,num_expediente);
		
		if (expedienteEntity == null) {
			throw new ExpedienteNoEncontradoException();
		}
		
		em.remove(expedienteEntity);
		
	}
	
	public Expedientes visualizarExpediente(long num_expediente) throws ExpedienteNoEncontradoException{

		Expedientes expedienteEntity = em.find(Expedientes.class,num_expediente);
		
		if (expedienteEntity == null) {
			throw new ExpedienteNoEncontradoException();
		}
		
		return expedienteEntity;
	}
	
	public void modificarExpediente(Expedientes expediente) throws NeuBDExceptions{
		
		Expedientes exp = em.find(Expedientes.class, expediente.getNum_expediente());
		
		if (exp == null) {
			throw new usuarioNoEncontradoException();
		}
		
		em.merge(exp);
	}

}

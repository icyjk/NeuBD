package NeuBDProyectoSIIexceptions;

public class NeuBDExceptions extends Exception {
	
	public NeuBDExceptions(){};
	
	public NeuBDExceptions(String message){
		super(message);
	}

}

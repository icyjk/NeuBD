package NeuBDProyectoSIIEjb;

import java.util.List;

import javax.ejb.Local;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSII.Matricula;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

@Local
public interface GestionMatricula {

	public void eliminarMatricula(Expedientes exp) throws NeuBDExceptions;
	
	public Matricula visualizarMatricula(Expedientes exp) throws NeuBDExceptions;
	
	public void modificarAlumno(Matricula m) throws NeuBDExceptions;
	
	public List<Matricula> listaMatricula() throws NeuBDExceptions;
	
}

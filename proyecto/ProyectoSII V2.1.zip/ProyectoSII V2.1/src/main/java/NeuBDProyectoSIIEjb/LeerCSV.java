package NeuBDProyectoSIIEjb;


import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;



public class LeerCSV {
	private static final String SAMPLE_CSV_FILE_PATH = "./users.csv";
	
    public static void main(String[] args) throws IOException {
        try (
            Reader reader = Files.newBufferedReader(Paths.get(SAMPLE_CSV_FILE_PATH));
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
        ) {
            for (CSVRecord csvRecord : csvParser) {
                // Accediendo a los valores por el indice de la columna
                String DNI = csvRecord.get(0);
                String nombre = csvRecord.get(1);
                String priApellido = csvRecord.get(2);
                String secApellido = csvRecord.get(3);
                String numExp = csvRecord.get(4);
                String numArchivo = csvRecord.get(5);
                String emInstitucional = csvRecord.get(6);
                String emPersonal = csvRecord.get(7);
                String telefono = csvRecord.get(8);
                String movil = csvRecord.get(9);
                String direccion = csvRecord.get(10);
                String localidad = csvRecord.get(11);
                String provincia = csvRecord.get(12);
                String cp = csvRecord.get(13);
                String fechaMatricula = csvRecord.get(14);
                String turnoPref = csvRecord.get(15);
                String gruposAsig = csvRecord.get(16);
                String notaMedia = csvRecord.get(17);
                String credSuperados = csvRecord.get(18);
                String CREDITOS_FB = csvRecord.get(19);
                String CREDITOS_OB = csvRecord.get(20);
                String CREDITOS_OP = csvRecord.get(21);
                String CREDITOS_CF = csvRecord.get(22);
                String CREDITOS_PE = csvRecord.get(23);
                String CREDITOS_TF = csvRecord.get(24);
                
               
                
            }
        }
    }
}

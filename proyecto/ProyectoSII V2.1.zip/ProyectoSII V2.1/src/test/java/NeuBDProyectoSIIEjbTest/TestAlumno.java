package NeuBDProyectoSIIEjbTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSIIEjb.GestionAlumno;
import NeuBDProyectoSIIEjb.GestionGrupo;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;
import es.uma.informatica.sii.anotaciones.Requisitos;

public class TestAlumno {

	private static final Logger LOG = Logger.getLogger(TestAlumno.class.getCanonicalName());

	private static final String AlumnoEJB = "java:global/classes/AlumnoEJB";
	private static final String GLASSFISH_CONFIGI_FILE_PROPERTY = "org.glassfish.ejb.embedded.glassfish.configuration.file";
	private static final String CONFIG_FILE = "target/test-classes/META-INF/domain.xml";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "ProyectoTest";
	
	private static EJBContainer ejbContainer;
	private static Context ctx;
	
	private GestionAlumno gestionAlumno;
	
	@BeforeClass
	public static void setUpClass() {
		Properties properties = new Properties();
		properties.setProperty(GLASSFISH_CONFIGI_FILE_PROPERTY, CONFIG_FILE);
		ejbContainer = EJBContainer.createEJBContainer(properties);
		ctx = ejbContainer.getContext();
	}
	
	@Before
	public void setup() throws NamingException  {
		gestionAlumno = (GestionAlumno) ctx.lookup(AlumnoEJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	
	
	
	//FALLAN LOS TEST Y NOSE PORQUE, CREO QUE ES POR IMPORTAR LOS DATOS A LA BD
	
	@Requisitos({"RF-05"})
	@Test
	public void testEliminarAlumno() {
		try {
			
			List<Alumno> listaAlumnos = gestionAlumno.listaAlumno();
			
			int tamañoinicial = listaAlumnos.size();
			
			Alumno Alumnoaeliminar = listaAlumnos.get(0);
			
			gestionAlumno.eliminarAlumno(Alumnoaeliminar.getID());
			
			listaAlumnos = gestionAlumno.listaAlumno();
			
			assertEquals(tamañoinicial-1, listaAlumnos.size());
			
			
			
		} catch (NeuBDExceptions e) {
			fail("No debería lanzarse excepción");
		}
		
		
		
		
	}
	
	@Requisitos({"RF-05"})
	@Test
	public void testVisualizarAlumno() {
	try {
			
			Alumno alumno = gestionAlumno.listaAlumno().get(0);
			String ID = alumno.getID();
			
		
			assertTrue(alumno.equals(gestionAlumno.visualizarAlumno(ID)));	
			
			
		} catch (NeuBDExceptions e) {
			fail("No debería lanzarse excepción");
		}
		
		
	}
	
	@Requisitos({"RF-05"})
	@Test
	@Ignore
	///////////////////////////////////////////////////////////////FALLA
	public void testModificarAlumno() {
		try {
			
			Alumno alumno = gestionAlumno.listaAlumno().get(0);
			alumno.setID("0");
			
			gestionAlumno.modificarAlumno(alumno);
			
		
			assertTrue(!alumno.equals(gestionAlumno.listaAlumno().get(0)));	
			
			
		} catch (NeuBDExceptions e) {
			fail("No debería lanzarse excepción");
		}
		
		
	}
	
	
	//Nose como orientarlo para hacer la prueba
	@Requisitos({"RF-05"})
	@Test
	public void testListaAlumno() {
		
		try {
			
			List<Alumno> listaAlumnos = gestionAlumno.listaAlumno();
		
			
			
		} catch (NeuBDExceptions e) {
			fail("No debería lanzarse excepción");
		}
		
		
	}
	
	
	
	
	
	
	
	@AfterClass
	public static void tearDownClass() {
		if (ejbContainer != null) {
			ejbContainer.close();
		}
	}
	
}

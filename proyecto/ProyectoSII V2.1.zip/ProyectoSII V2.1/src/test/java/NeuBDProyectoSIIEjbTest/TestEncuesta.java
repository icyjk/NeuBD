package NeuBDProyectoSIIEjbTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import NeuBDProyectoSII.Encuesta;
import NeuBDProyectoSIIEjb.GestionEncuesta;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

public class TestEncuesta {
	private static final Logger LOG = Logger.getLogger(TestAlumno.class.getCanonicalName());

	private static final String EncuestaEJB = "java:global/classes/EncuestaEJB";
	private static final String GLASSFISH_CONFIGI_FILE_PROPERTY = "org.glassfish.ejb.embedded.glassfish.configuration.file";
	private static final String CONFIG_FILE = "target/test-classes/META-INF/domain.xml";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "ProyectoTest";
	
	private static EJBContainer ejbContainer;
	private static Context ctx;
	
	private GestionEncuesta gestionEncuesta;
	
	@BeforeClass
	public static void setUpClass() {
		Properties properties = new Properties();
		properties.setProperty(GLASSFISH_CONFIGI_FILE_PROPERTY, CONFIG_FILE);
		ejbContainer = EJBContainer.createEJBContainer(properties);
		ctx = ejbContainer.getContext();
	}
	
	@Before
	public void setup() throws NamingException  {
		gestionEncuesta = (GestionEncuesta) ctx.lookup(EncuestaEJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	
	
	@Test @Ignore
	public void testEliminarEncuesta() {
		try {
			
			List<Encuesta> listaEncuesta = gestionEncuesta.listaEncuestas();
			
			int tamañoinicial = listaEncuesta.size();
			
			Encuesta Encuestaaeliminar = listaEncuesta.get(0);
			
			gestionEncuesta.eliminarEncuesta(Encuestaaeliminar.getFecha_de_envio());
			
			listaEncuesta = gestionEncuesta.listaEncuestas();
			
			assertEquals(tamañoinicial-1, listaEncuesta.size());
			
			
			
		} catch (NeuBDExceptions e) {
			fail("No debería lanzarse excepción");
		}
		
		
		
		
	}
	
	
	
	@AfterClass
	public static void tearDownClass() {
		if (ejbContainer != null) {
			ejbContainer.close();
		}
	}
}

package NeuBDProyectoSIIEjbTest;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Asignatura;
import NeuBDProyectoSII.Centro;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSII.Grupos_por_asignatura;
import NeuBDProyectoSII.Titulacion;

public class BaseDatos {
	
	public static void inicializaBaseDatos(String nombreUnidadPersistencia) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(nombreUnidadPersistencia);
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		//centro
		Centro centroETSI = new Centro("ETSI","Calle ruben del pozo","639004675",null);
		
		List<Centro> listacentros = new ArrayList<Centro>();
		listacentros.add(centroETSI);
		
		em.persist(centroETSI);
		//Titulacion
		Titulacion titulacionInf = new Titulacion("Informatica", 360,listacentros, null, null, null);
		
		em.persist(titulacionInf);
		
		//Asignatura
		Asignatura calculo = new Asignatura(666, 101, 3, 3, 6, false, "Calculo", 1, "caracter", 0, "PrimerCuatri", "Español"
				,titulacionInf , null, null, null);
		em.persist(calculo);
		
		//Grupo
		Grupo grupoAinf = new Grupo("1",'A',"Mañana",true, true, "", 50 , titulacionInf, null, null,null,null);
		
		em.persist(grupoAinf);
		/*
		/////////////////////////////////////////////////////////////////////////////IMPORTANTE
		//////Si teneis un objeto referenciado en otro, si qereis meterlo dentro de la bd como en Calculo A
		////// hay qe hacer introducir en los OneToMany y ManyToOne y derivados esto ", cascade = {CascadeType.PERSIST,CascadeType.REMOVE}"

		//Grupo Por Asignatura
		 */
		Grupos_por_asignatura calculoA = new Grupos_por_asignatura(grupoAinf, calculo, 1, true, null);
		em.persist(calculoA);
		
		//Expediente 
		Expedientes expediente = new Expedientes(true, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null);
		List<Expedientes> listaExpedientes = new ArrayList<Expedientes>();
		listaExpedientes.add(expediente);
		em.persist(expediente);
		
		//Alumno
		Alumno alumno = new Alumno("Gustavo","Gracias","Molina","ola@prueba.com","ola@uma.es","75848437","calle falsa n25","malaga","malaga","29010",listaExpedientes," "," ");
		Alumno alumno2 = new Alumno ();
		
		em.persist(alumno);
		em.persist(alumno2);
		//em.persist(alumno2);
		
		

		
		
		
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

}

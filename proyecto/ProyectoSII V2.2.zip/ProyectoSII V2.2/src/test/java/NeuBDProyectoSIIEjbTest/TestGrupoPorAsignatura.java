package NeuBDProyectoSIIEjbTest;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import NeuBDProyectoSII.Asignatura;
import NeuBDProyectoSII.Centro;
import NeuBDProyectoSII.Grupo;
import NeuBDProyectoSII.NewId_GrupoPorAsignatura_grupo_asignatura;
import NeuBDProyectoSII.Titulacion;
import NeuBDProyectoSIIEjb.GestionGrupoPorAsignatura;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

public class TestGrupoPorAsignatura {
	private static final Logger LOG = Logger.getLogger(TestGrupo.class.getCanonicalName());

	private static final String Grupo_Por_Asignatura_EJB = "java:global/classes/Grupos_por_asignatura_Ejb";
	private static final String GLASSFISH_CONFIGI_FILE_PROPERTY = "org.glassfish.ejb.embedded.glassfish.configuration.file";
	private static final String CONFIG_FILE = "target/test-classes/META-INF/domain.xml";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "ProyectoTest";
	
	private static EJBContainer ejbContainer;
	private static Context ctx;
	
	private GestionGrupoPorAsignatura gestionGrupoPorAsignatura;
	
	@BeforeClass
	public static void setUpClass() {
		Properties properties = new Properties();
		properties.setProperty(GLASSFISH_CONFIGI_FILE_PROPERTY, CONFIG_FILE);
		ejbContainer = EJBContainer.createEJBContainer(properties);
		ctx = ejbContainer.getContext();
	}
	
	@Before
	public void setup() throws NamingException  {
		gestionGrupoPorAsignatura = (GestionGrupoPorAsignatura) ctx.lookup(Grupo_Por_Asignatura_EJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	
	@Test
	public void testListaGruposPorAsignatura() {
		try {
			int numAsignaturas = gestionGrupoPorAsignatura.listaGruposPorAsignatura().size();
						//AUX
						//centro
						Centro centroETSI = new Centro("ETSI","Calle ruben del pozo","639004675",null);
						
						List<Centro> listacentros = new ArrayList<Centro>();
						listacentros.add(centroETSI);
						//Titulacion
						Titulacion titulacionInf = new Titulacion("Informatica", 360,listacentros, null, null, null);
						//Asignatura
						Asignatura calculo = new Asignatura(666, 101, 3, 3, 6, false, "Calculo", 1, "caracter", 0, "PrimerCuatri", "Español"
								,titulacionInf , null, null, null);
						
						//Grupo
						Grupo grupoAinf = new Grupo("1",'A',"Mañana",true, true, "", 50 , titulacionInf, null, null,null,null);
			gestionGrupoPorAsignatura.buscarGrupoPorAsignatura(new NewId_GrupoPorAsignatura_grupo_asignatura(grupoAinf.getId(), calculo.getReferencia(), 1));
			int numActualizado = gestionGrupoPorAsignatura.listaGruposPorAsignatura().size();
			assertEquals(numAsignaturas+1, numActualizado);
		} catch (NeuBDExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@AfterClass
	public static void tearDownClass() {
		if (ejbContainer != null) {
			ejbContainer.close();
		}
	}
	
}

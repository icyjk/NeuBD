package NeuBDProyectoSIIEjb;

import java.util.Date;
import java.util.List;

import NeuBDProyectoSII.Encuesta;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

public interface GestionEncuesta {
	
	public void eliminarEncuesta(Date fecha) throws NeuBDExceptions;
	
	public Encuesta visualizarEncuesta(Date fecha) throws NeuBDExceptions;
	
	public void modificarEncuesta(Encuesta encuesta) throws NeuBDExceptions;
	
	public List<Encuesta> listaEncuestas() throws NeuBDExceptions;
}

package NeuBDProyectoSIIEjb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import NeuBDProyectoSII.Alumno;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSII.Matricula;
import NeuBDProyectoSIIexceptions.AlumnoSInDatosParaCrearException;
import NeuBDProyectoSIIexceptions.MatriculaNoEncontradaException;
import NeuBDProyectoSIIexceptions.MatriculaSinDatosParaCrearException;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;
import NeuBDProyectoSIIexceptions.usuarioNoEncontradoException;

@Stateless
public class MatriculaEJB implements GestionMatricula{
	@PersistenceContext(name="ProyectoSII")
	private EntityManager em;
	
	
	@Override
	public void eliminarMatricula(Expedientes exp) throws MatriculaNoEncontradaException {
		// TODO Auto-generated method stub
		Matricula matricula = em.find(Matricula.class, exp);
		
		if(matricula==null) {
			throw new MatriculaNoEncontradaException();
		}
		
		em.remove(matricula);
	}

	@Override
	public Matricula visualizarMatricula(Expedientes exp) throws MatriculaNoEncontradaException {
		Matricula matricula= em.find(Matricula.class, exp);
		
		if (matricula == null) {
			throw new MatriculaNoEncontradaException();
		}
		
		return matricula;
	}

	@Override
	public void modificarAlumno(Matricula m) throws MatriculaNoEncontradaException {
		// TODO Auto-generated method stub
		Matricula matricula= em.find(Matricula.class, m.getExpedientes());
		
		if (matricula == null) {
			throw new MatriculaNoEncontradaException();
		}
		
		em.merge(m);
		
	}

	@Override
	public List<Matricula> listaMatricula() throws MatriculaNoEncontradaException {
		// TODO Auto-generated method stub
		return em.createNamedQuery("Matricula.todos",Matricula.class).getResultList();
	}

	@Override
	public void anyadirMatricula(Matricula m) throws MatriculaSinDatosParaCrearException {
		// TODO Auto-generated method stub
		if (m == null) {
			throw new MatriculaSinDatosParaCrearException();
		}
		
		em.merge(m);
		
	}

}

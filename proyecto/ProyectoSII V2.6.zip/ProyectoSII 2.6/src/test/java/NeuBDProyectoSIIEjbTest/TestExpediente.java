package NeuBDProyectoSIIEjbTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import NeuBDProyectoSII.Centro;
import NeuBDProyectoSII.Expedientes;
import NeuBDProyectoSII.Titulacion;
import NeuBDProyectoSIIEjb.GestionAsignatura;
import NeuBDProyectoSIIEjb.GestionExpediente;
import NeuBDProyectoSIIEjb.GestionTitulacion;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

public class TestExpediente {
	
	private static final String Expediente_EJB = "java:global/classes/ExpedienteEJB";
	private static final String GLASSFISH_CONFIGI_FILE_PROPERTY = "org.glassfish.ejb.embedded.glassfish.configuration.file";
	private static final String CONFIG_FILE = "target/test-classes/META-INF/domain.xml";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "ProyectoTest";
	
	private static EJBContainer ejbContainer;
	private static Context ctx;
	
	private GestionExpediente gestionExpediente;
	
	@BeforeClass
	public static void setUpClass() {
		Properties properties = new Properties();
		properties.setProperty(GLASSFISH_CONFIGI_FILE_PROPERTY, CONFIG_FILE);
		ejbContainer = EJBContainer.createEJBContainer(properties);
		ctx = ejbContainer.getContext();
	}
	
	@Before
	public void setup() throws NamingException  {
		gestionExpediente = (GestionExpediente) ctx.lookup(Expediente_EJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);

	}
	
	
	@Test
	@Ignore
	public void testEliminarExpediente() {
		try {
		
			
			List<Expedientes> expedientes = gestionExpediente.listaExpedientes();
			
			int tamañoinicial = expedientes.size();
			
			Expedientes expedienteaeliminar = expedientes.get(0);
			
			gestionExpediente.eliminarExpediente(expedienteaeliminar);
			
			int expedientees = gestionExpediente.listaExpedientes().size();
			
			assertEquals(tamañoinicial-1, expedientees);
			
			
			
		} catch (NeuBDExceptions e) {
			fail("No debería lanzarse excepción");
		}
	}
	
	
	@Test
	public void testEliminarExpedienteMal() {
		try{
		
			Expedientes expediente = new Expedientes(true, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null);
			expediente.setNum_expediente(0);
			
			gestionExpediente.eliminarExpediente(expediente);
			fail("Deberia lanzar una excepcion");
			
		}catch(NeuBDExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testBuscarExpediente() {
		try {
			
			List<Expedientes> expedientes = gestionExpediente.listaExpedientes();
			
			Expedientes e = expedientes.get(0);
			
			Expedientes aux = gestionExpediente.visualizarExpediente(e);
			assertTrue(e.equals(aux));
			
		} catch (NeuBDExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testBuscarExpedienteMal() {
		try {
			
		Expedientes expediente = new Expedientes(true, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null);
		expediente.setNum_expediente(0);
			
		gestionExpediente.visualizarExpediente(expediente);
			
			fail("Deberia lanzar excepcion");
		} catch (NeuBDExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void testModificarExpediente() {
		try {
			
			Expedientes e = gestionExpediente.listaExpedientes().get(0);
			
			e.setCreditos_superado(100);
			
			gestionExpediente.modificarExpediente(e);
			
			
			assertEquals(100,gestionExpediente.visualizarExpediente(e).getCreditos_superado());
		}catch(NeuBDExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	@AfterClass
	public static void tearDownClass() {
		if (ejbContainer != null) {
			ejbContainer.close();
		}
	}

}

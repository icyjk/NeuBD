package NeuBDProyectoSIIEjb;

import java.io.IOException;

import NeuBDProyectoSII.Centro;
import NeuBDProyectoSII.Titulacion;
import NeuBDProyectoSIIexceptions.AlumnoSInDatosParaCrearException;
import NeuBDProyectoSIIexceptions.NeuBDExceptions;

public interface GestionLeerCSV {
	public void insertarAlumnoCSV(Centro cen, Titulacion titu,String route)throws IOException, AlumnoSInDatosParaCrearException;
	public void insertarTitulacionCSV(Centro cen, String route)throws IOException, NeuBDExceptions;
	public void insertarAsignaturaCSV(String route)throws IOException, NeuBDExceptions;
	public void insertarOptativaCSV(String route)throws IOException, NeuBDExceptions;
}
